$(function () {    
    $(document).ready(function () {
         $('#dttable').DataTable({
             dom: 'Blfrtip',
             buttons: ['excel']
         });
     });
 }); 